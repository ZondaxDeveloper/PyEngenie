from setuptools import setup

setup(
    name="pyEngenie",
    version="3.2.0",
    description="pyMachioneCalculs: realiza calculos matematicos facilmente llamando a una sola fincion",
    author="FireStickMXXstidios",
    packages=["pyEngenie", "pyEngenie.Calculs", "pyEngenie.pyEngenieView"]
)