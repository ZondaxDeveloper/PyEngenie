def addition(opr1,opr2):
    AdditionResult = opr1 + opr2
    print("AdditionResult",AdditionResult)
def subtraction(opr1, opr2):
    SubstractResult = opr1 - opr2
    print("SubstractResult:",SubstractResult)
def multiplication(opr1, opr2):
    multiplication = opr1 * opr2
    print("Multiplication:",multiplication)
def division(opr1, opr2):
    division = opr1 / opr2
    print("Division:",division)
def mathematicalpower(opr1, opr2):
    mathematicalpower = opr1**opr2
    print("MathematicalPower:", mathematicalpower)
def Round(number):
    print("Round:", round(number))
class ResultTotal():
    def __init__(self, firstNumber, secondNumber):
        print("RESULTS:")
        addition(firstNumber, secondNumber)
        subtraction(firstNumber,secondNumber)
        multiplication(firstNumber, secondNumber)
        division(firstNumber,secondNumber)
        mathematicalpower(firstNumber,secondNumber)
        Round(firstNumber)
