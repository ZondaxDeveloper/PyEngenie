from io import *
class CreateArchiveAndWrite():
    def __init__(self, archiveName, text):
        archiveName = archiveName
        engenieArchive = open(archiveName, "w")
        text = text
        WriteText = text
        engenieArchive.write(WriteText)
        engenieArchive.close()
CreateArchiveAndWrite("hola.txt", "hola")
        