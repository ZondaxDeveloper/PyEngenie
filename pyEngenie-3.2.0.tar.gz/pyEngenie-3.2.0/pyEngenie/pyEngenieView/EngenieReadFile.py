from io import *
class CreateArchiveAndRead():
    def __init__(self, archiveName):
        archiveName = archiveName
        engenieArchive = open(archiveName, "r")
        engenieArchive.seek(0)

        engenieArchive.read()
        engenieArchive.close()
        print(engenieArchive) 
ll = CreateArchiveAndRead("hola.txt")